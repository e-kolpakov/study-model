from agents.base_agent import BaseAgent

__author__ = 'john'


class Resource(BaseAgent):
    pass