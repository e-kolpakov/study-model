__author__ = 'john'


class OutputRenderBase(object):
    def render(self, results):
        raise NotImplemented()
